#!/bin/bash
chmod 666 /var/www/html/tweets.txt
service httpd start

